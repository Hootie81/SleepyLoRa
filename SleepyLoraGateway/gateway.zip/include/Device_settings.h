#define TIME_TO_SLEEP  60      // Time ESP32 will go to sleep (in seconds).
#define MAX_AWAKE_TIME 300000   // max time the device can be awake
#define UPDATE_PERIOD 300        // how often to send updates
#define OTP_RANGE 5             // max time difference allowed for valid OTP, must be less than 15 due to return code
#define INTER_MESSAGE_DELAY 90  // minimum time after transmitting in ms

byte aes_key[] = { 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C };
uint8_t hmacKey[] = {0x4d, 0x79, 0x4c, 0x65, 0x67, 0x6f, 0x44, 0x6f, 0x6f, 0x72};

#define GATEWAY_NODE_ID 0x00FF66FA
#define GATEWAY

#define BATTERY_PIN 37
#define BATTERY_ADC_PIN 01

/************************* WiFi Access Point *********************************/

#define WLAN_SSID "HAOS"
#define WLAN_PASS "vfYUHe43n"


/************************* Adafruit.io Setup *********************************/

#define AIO_SERVER      "192.168.23.128"
//#define AIO_SERVER      "192.168.29.149"
#define AIO_SERVERPORT  1883
//#define CONNECT_TIMEOUT_MS 30000

#define AIO_USERNAME "blinds"
#define AIO_KEY      "vfYUHblinds"

/************************* NTP Settings *************************************/

#define NTP_SERVER              "192.168.23.128"
//#define NTP_SERVER              "au.pool.ntp.org"
//#define NTP_SERVER              "100.93.110.28"
#define NTP_OFFSET              28800  //in seconds
#define NTP_UPDATE_INTERVAL     600000 //in milliseconds
