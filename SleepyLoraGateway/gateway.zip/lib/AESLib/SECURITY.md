# Security Policy

## Supported Versions

All versions of this project are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 2.2.x   | :white_check_mark: |

## Reporting a Vulnerability

In case you find a vulnerability, please file an issue here. I'll respond as soon as possible.
